function activateLink(linkId) {
    $('#'+linkId).parent().addClass('active');
}