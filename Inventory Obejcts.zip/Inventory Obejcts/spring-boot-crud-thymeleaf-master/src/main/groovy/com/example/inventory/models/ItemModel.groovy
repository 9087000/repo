package com.example.inventory.models

import org.hibernate.annotations.CreationTimestamp

import javax.persistence.*

@Entity
@Table(name = "item")
class ItemModel {
    private Long ShipperBillNo
    private String ShipperName
    private Date Date
    private String Cosignee
    private String POL
    private String POD
    private String[] Client;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ShipperBillNo", nullable = false)
    Long getShipperBillNo() {
        return ShipperBillNo
    }

    void setItemId(Long ShipperBillNo) {
        this.ShipperBillNo = ShipperBillNo
    }

    @Basic
    @Column(name = "ShipperName", nullable = false, length = 256)
    String getShipperName() {
        return ShipperName
    }

    void setShipperName(String ShipperName) {
        this.ShipperName = ShipperName
    }

    @Basic
    @Column(name = "Cosignee", nullable = false, length = 512)
    String getCosignee() {
        return Cosignee
    }

    void setCosignee(String Cosignee) {
        this.Cosignee = Cosignee
    }

    @Basic
    @Column(name = "POL", nullable = false, length = 512)
    String getPOL() {
        return POL
    }

    void setPOL(String POL) {
        this.POL = POL
    }

    @Basic
    @Column(name = "POD", nullable = false, length = 512)
    String getPOD() {
        return POD
    }

    void setPOD(String POD) {
        this.POD = POD
    }

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "added_on", nullable = false)
    Date getAddedOn() {
        return addedOn
    }

    void setAddedOn(Date addedOn) {
        this.addedOn = addedOn
    }

    @Override
    boolean equals(Object o) {
        if (this == o) return true
        if (o == null || getClass() != o.getClass()) return false

        ItemModel itemModel = (ItemModel) o

        if (ShipperBillNo != null ? !itemId.equals(itemModel.ShipperBillNo) : itemModel.ShipperBillNo != null) return false
        if (ShipperName != null ? !itemName.equals(itemModel.ShipperName) : itemModel.ShipperName != null) return false
        if (Date != null ? !description.equals(itemModel.Date) : itemModel.Date != null)
            return false
        if (addedOn != null ? !addedOn.equals(itemModel.addedOn) : itemModel.addedOn != null) return false

        return true
    }

    @Override
    int hashCode() {
        int result = itemId != null ? itemId.hashCode() : 0
        result = 31 * result + (itemName != null ? itemName.hashCode() : 0)
        result = 31 * result + (description != null ? description.hashCode() : 0)
        result = 31 * result + (addedOn != null ? addedOn.hashCode() : 0)
        return result
    }

    @OneToOne(mappedBy = "itemByItemId")
    InventoryModel getInventoryByItemId() {
        return inventoryByItemId
    }

    void setInventoryByItemId(InventoryModel inventoryByItemId) {
        this.inventoryByItemId = inventoryByItemId
    }
}
