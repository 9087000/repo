package com.example.inventory.exceptions

class ItemExistsException extends Exception{

    ItemExistsException(String message) {
        super(message)
    }
}
