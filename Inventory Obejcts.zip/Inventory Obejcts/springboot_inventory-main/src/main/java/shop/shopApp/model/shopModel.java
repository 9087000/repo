package shop.shopApp.model;

import javax.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name="`inventory`")
public class shopModel {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="Shipper Bill No")
    private Long Shipper Bill No;
	
	@Column(name="Shipper Name")
    private Integer Shipper Name;
    
    @Column(name="date")
    private Date Date;

    @Column(name="Cosignee1")
    private String Cosignee1;
    
    @Column(name="POL")
    private Integer POL;
    
    
    @Column(name="POD")
    private Integer POD;
    
    @Column(name="Client")
    private String[] Client;
    
   
    
    
    
}
