package shop.shopApp.model;

import javax.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name="`inventory`")
public class ShopInventoryModel {
	 	@Column(name="Materials")
	    private Integer Materials;
	    
	    @Column(name="Type")
	    private String[] type;
	    
	    @Column(name="Width")
	    private Integer Width;
	    
	    @Column(name="Height")
	    private Integer Height;
	    
	    @Column(name="Breath")
	    private Integer Breath;
	    
	    @Column(name="Count")
	    private Integer Count;
	    
}
