package com.example.icecontroller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcecontrollerApplicationTests {

    @Test
    void contextLoads() {
    }

}
